import serial
import sys
import time
import pygame

pygame.init()
j = pygame.joystick.Joystick(0)
j.init()

def main():
	mode = "land"
	prevOutput = b'm:0000:0000&'
	# Open serial port
	ser = serial.Serial('/dev/cu.usbserial-DN018V82', 9600)
	ser.write(b't:0090:0000&')

	while(True):

		pygame.event.pump()
		output = ""

		if j.get_button(8) != 0:
			ser.write(b'm:0000:0000')
			ser.write(b'p:0000:0000')
			j.quit()
			exit("Controller Quit")

		elif j.get_button(1) != 0:
			if mode == "land":
				output = "t:0087:0000&"
				mode = "sea"
			else: 
				mode = "land"
				output = "t:0180:0000&"

		elif(mode == "land"):
			output = "m"
			if abs(j.get_axis(1)) >= 0.05:
				movement = int(j.get_axis(1)*-255)
				if movement>0:
					stringInput = str(movement)
					while(len(stringInput)<4):
						stringInput = "0"+stringInput
					output = output+":"+stringInput
				else:
					movement = abs(movement)
					stringInput = str(movement)
					while(len(stringInput)<3):
						stringInput = "0"+stringInput
					output = output+":-"+stringInput
			else:
				output = output+":0000"

			if abs(j.get_axis(3)) >= 0.05:
				movement = int(j.get_axis(3)*-255)
				if movement>0:
					stringInput = str(movement)
					while(len(stringInput)<4):
						stringInput = "0"+stringInput
					output = output+":"+stringInput+"&"
				else:
					movement = abs(movement)
					stringInput = str(movement)
					while(len(stringInput)<3):
						stringInput = "0"+stringInput
					output = output+":-"+stringInput+"&"
			else:
				output = output+":0000"+"&"
			
		elif(mode == "sea"):
			output = "p"
			movement = int(j.get_axis(1)*-255)
			if movement>0:
				stringInput = str(movement)
				while(len(stringInput)<4):
					stringInput = "0"+stringInput
				output = output+":"+stringInput
			else:
				movement = abs(movement)
				stringInput = str(movement)
				while(len(stringInput)<3):
					stringInput = "0"+stringInput
				output = output+":-"+stringInput

			movement = int((j.get_axis(2)+1)*90)
			stringInput = str(movement)
			while(len(stringInput)<4):
				stringInput = "0"+stringInput
			output = output+":"+stringInput+"&"

		output = output.encode()
		#if(output != prevOutput):
		ser.write(output)
		if(output != prevOutput):
			print(output)
			prevOutput = output
		if(output == b't:0180:0000&' or output == b't:0087:0000&'):
			time.sleep(0.90)
		time.sleep(0.1)

if __name__ == '__main__':
    main()
